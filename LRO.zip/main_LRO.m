clc 
clear 
% Population size and stoppoing condition 
pop_size=60;  
max_iter=1000;  

% Define your objective function's details here
Function_name='F1';
% variables_no=10;
% lower_bound=-100; % can be a vector too
% upper_bound=100; % can be a vector too
[lb,ub,dim,fobj]=Get_Functions_details(Function_name);
      
[Best_sLRO,Best_pLRO,LRO_curve]=LRO(pop_size,max_iter,lb,ub,dim,fobj);

fig=figure(1);
semilogx(LRO_curve,'r-','LineWidth',3)
xlabel('Iteration')
ylabel('Best J')
title('F1')
set(gca,'FontName','Times New Roman','FontSize',12,'LineWidth',1.5);

