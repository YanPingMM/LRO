function [Best_Score,Best,convergence_curve]=LRO(searchagents,max_iter,lb,ub,dim,fobj)


% initialize
Best=[];
Best_Score=inf;

lb=ones(1,dim).*(lb);  
ub=ones(1,dim).*(ub);


%Initialize the first random population
Z=zeros(searchagents,dim);
Z(1,:) =rand(1, dim);
Alpa=0.499;
for i=2:searchagents
    for j=1:dim
    if  Z(i-1,j)<Alpa
        Z(i,j)=Z(i-1,j)/Alpa;
    else
        Z(i,j)=(1-Z(i-1,j))/(1-Alpa);
    end
    end
end
X= zeros(searchagents,dim);
for i=1:searchagents
    X(i,:) =lb+(ub-lb).*Z(i,:);
end    


convergence_curve=zeros(1,max_iter);
fitness=zeros(1,searchagents);
%Calculate the fitness value of the initial population
for i=1:searchagents  
    fitness(i)=fobj(X(i,:));
    if fitness(i)<Best_Score 
            Best_Score=fitness(i); 
            Best=X(i,:);
    end
end
GX=X(:,:);

for q=1:max_iter 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Phase 1: Literature retrieval
for i=1:searchagents
   t1=randperm(searchagents,1);
   t2=randperm(searchagents,1);
   GX(i,:)=X(i,:)+rand.*(X(t1,:)-X(t2,:));
end

GX = boundaryCheck(GX, lb, ub);


% Group formation operation 
    for i=1:searchagents
         New_Fit= fobj(GX(i,:));          
         if New_Fit<fitness(i)
            fitness(i)=New_Fit;
            X(i,:)=GX(i,:);
         end
         if New_Fit<Best_Score 
            Best_Score=New_Fit; 
            Best=GX(i,:);
         end
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Phase 2: Information filtering
for i=1:searchagents
 bt=1.5;
 sigma_v=1;
 sigma_u=(gamma(1+bt).*sin(pi*bt/2))./(gamma((1+bt)./2)*bt*2^((bt-1)/2)).^(1/bt).*(1-q/max_iter);
 u=normrnd(0,sigma_u,searchagents,dim);
 v=normrnd(0,sigma_v,searchagents,dim);
 levy=u./(abs(v).^(1/bt));
 GX(i,:) =X(i,:)+levy(i,:).*(X(i,:)-Best);
end
GX = boundaryCheck(GX, lb, ub);


% Group formation operation 
    for i=1:searchagents
         New_Fit= fobj(GX(i,:));          
         if New_Fit<fitness(i)
            fitness(i)=New_Fit;
            X(i,:)=GX(i,:);
         end
         if New_Fit<Best_Score 
            Best_Score=New_Fit; 
            Best=GX(i,:);
         end
    end

   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Phase 3: Literature screening
for i=1:searchagents
    c=0.15;
    GX(i,:) =X(i,:)+c*(2*rand-1)*exp(-q/max_iter).*X(i,:);
end

GX = boundaryCheck(GX, lb, ub);

% Group formation operation 
   for i=1:searchagents
         New_Fit= fobj(GX(i,:));          
         if New_Fit<fitness(i)
            fitness(i)=New_Fit;
            X(i,:)=GX(i,:);
         end
         if New_Fit<Best_Score 
            Best_Score=New_Fit; 
            Best=GX(i,:);
         end
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%Phase 4: Personal competence lift
for i=1:searchagents
    if mean(fitness)<=fitness(i)
       pBest(i,:)=ub+rand(1,dim).*(lb-Best);
       GX(i,:)=pBest(i,:)+rand(1).*(Best-pBest(i,:));
    else
       GX(i,:)=Best+((2*rand-1).*Best-(2*rand-1).*X(i,:));
    end
end

GX = boundaryCheck(GX, lb, ub);


% Group formation operation 
    for i=1:searchagents
         New_Fit= fobj(GX(i,:));          
         if New_Fit<fitness(i)
            fitness(i)=New_Fit;
            X(i,:)=GX(i,:);
         end
         if New_Fit<Best_Score 
            Best_Score=New_Fit; 
            Best=GX(i,:);
         end
    end
% end 
convergence_curve(q)=Best_Score;
end %end for the main loop
end